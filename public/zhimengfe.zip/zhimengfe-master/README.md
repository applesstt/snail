# ZhimengFE
见微知萌前端培训项目

![Moe icon](http://snailpa.com/img/moe120.png)

##基础资源

* [HTML教程](http://www.w3school.com.cn/html/index.asp)

* [CSS教程](http://www.w3school.com.cn/css/index.asp)

* [JavaScript教程](http://www.w3school.com.cn/js/index.asp)

***

##知识结构

简单看一下即可

* [前端知识结构图](https://github.com/JacksonTian/fks)

* [前端技术趋势](http://applesstt.github.io/RKFE/)

***

##入学作业

请在学习上述知识后，完成下面的作业，我们将根据作业的完成情况，筛选学员。

####作业要求

    参照baidu首页，制作一个相同的页面，尽可能与baidu页面效果一致。过程中遇到问题请自行搜索解决。

	可以在本页面找到“Download ZIP”按钮，解压后开发所需的文件资源都在baidu文件夹中，其中的页面文件为/baidu/index.html。




